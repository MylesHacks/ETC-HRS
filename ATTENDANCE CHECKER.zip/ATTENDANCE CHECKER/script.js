// Default accounts & students
if (!localStorage.getItem("users")) {
  const users = [
    { username: "admin", password: "admin123", role: "admin" },
    { username: "student1", password: "123", role: "student" },
    { username: "student2", password: "123", role: "student" }
  ];
  localStorage.setItem("users", JSON.stringify(users));
  localStorage.setItem("attendance", JSON.stringify({})); // empty record
}

function login(event) {
  event.preventDefault();
  const username = document.getElementById("username").value.trim();
  const password = document.getElementById("password").value.trim();

  const users = JSON.parse(localStorage.getItem("users"));
  const user = users.find(u => u.username === username && u.password === password);

  if (user) {
    localStorage.setItem("loggedInUser", JSON.stringify(user));
    if (user.role === "admin") {
      window.location.href = "admin.html";
    } else {
      window.location.href = "student.html";
    }
  } else {
    alert("Invalid credentials!");
  }
}

function logout() {
  localStorage.removeItem("loggedInUser");
  window.location.href = "index.html";
}

// Admin Dashboard
function loadAdminDashboard() {
  const loggedInUser = JSON.parse(localStorage.getItem("loggedInUser"));
  if (!loggedInUser || loggedInUser.role !== "admin") {
    window.location.href = "index.html";
    return;
  }

  const users = JSON.parse(localStorage.getItem("users"));
  const attendance = JSON.parse(localStorage.getItem("attendance"));
  const tbody = document.getElementById("studentTable");
  tbody.innerHTML = "";

  users.filter(u => u.role === "student").forEach(student => {
    const latestStatus = (attendance[student.username] || []).slice(-1)[0]?.status || "Not Marked";

    const row = `<tr>
      <td>${student.username}</td>
      <td>${latestStatus}</td>
      <td>
        <button onclick="markAttendance('${student.username}', 'Present')">Present</button>
        <button onclick="markAttendance('${student.username}', 'Late')">Late</button>
        <button onclick="markAttendance('${student.username}', 'Absent')">Absent</button>
      </td>
    </tr>`;
    tbody.innerHTML += row;
  });
}

function markAttendance(username, status) {
  const attendance = JSON.parse(localStorage.getItem("attendance"));
  if (!attendance[username]) attendance[username] = [];

  attendance[username].push({
    date: new Date().toLocaleDateString(),
    status
  });

  localStorage.setItem("attendance", JSON.stringify(attendance));
  loadAdminDashboard();
}

// Student Dashboard
function loadStudentDashboard() {
  const loggedInUser = JSON.parse(localStorage.getItem("loggedInUser"));
  if (!loggedInUser || loggedInUser.role !== "student") {
    window.location.href = "index.html";
    return;
  }

  const attendance = JSON.parse(localStorage.getItem("attendance"));
  const tbody = document.getElementById("attendanceTable");
  tbody.innerHTML = "";

  (attendance[loggedInUser.username] || []).forEach(record => {
    const row = `<tr>
      <td>${record.date}</td>
      <td>${record.status}</td>
    </tr>`;
    tbody.innerHTML += row;
  });
}